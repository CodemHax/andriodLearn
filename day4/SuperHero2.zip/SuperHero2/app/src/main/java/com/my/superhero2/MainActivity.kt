package com.my.superhero2

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.my.superhero2.ui.theme.SuperHero2Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i("MainActivity", "onCreate")

        setContent {
            SuperHero2Theme{
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Greeting("Iron Man", modifier = Modifier.padding(16.dp))
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        Log.i("MainActivity", "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.i("MainActivity", "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.i("MainActivity", "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.i("MainActivity", "onStop")
    }

    override fun onRestart() {
        super.onRestart()
        Log.i("MainActivity", "onRestart")

    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i("MainActivity", "onDestroy")
    }

}
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Column(
        modifier = Modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.faq_iag),
            contentDescription = "FAQ Image",
            modifier = Modifier.size(200.dp)
        )
        Text(
            text = "1. What happens if I enter the wrong OTP during account verification?",
            modifier = modifier,
            color = Color.Blue,
            textAlign = TextAlign.Left
        )
        Text(
            text = "If you enter the wrong OTP, you will be shown an error message and will have to re-enter the correct code. Please mention the correct OTP that you receive on your registered mobile number via SMS to proceed with the verification process successfully.",
            modifier = modifier,
            color = Color.Black,
            textAlign = TextAlign.Left
        )
        Text(
            text = "2. Where can I contact if I face any issues while booking a hotel room using the app?",
            modifier = modifier,
            color = Color.Blue,
            textAlign = TextAlign.Left
        )
        Text(
            text = "If you face any issues during your booking process you can reach out to our customer support team by at dummy@book_nest.com or call us at 9999999999.",
            modifier = modifier,
            color = Color.Black,
            textAlign = TextAlign.Left
        )
        Text(
            text = "3. Is my personal information secure when using this app?",
            modifier = modifier,
            color = Color.Blue,
            textAlign = TextAlign.Left
        )
        Text(
            text = "Yes, we value the trust of our users and prioritise the security of their personal information. All your data, including personal details and booking information is secure with us and protected using encryption protocols to ensure confidentiality.",
            modifier = modifier,
            color = Color.Black,
            textAlign = TextAlign.Left
        )
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    SuperHero2Theme {
        Greeting("Iron man")
    }
}